import java.util.*;

public class armstrong {

    public static void main(String[] args) {

        try

        {

            Scanner sc = new Scanner(System.in);

            System.out.print("Enter a number: ");

            int n = sc.nextInt();

            int temp = n;

            int r,s,sum=0;

            while(n>0){

                r = n%10;

                n = n/10;

                sum = sum + r*r*r;

            }

            if(temp==sum)

                System.out.println("it is an armstrong number");

            else

                System.out.println("it is not an armstrong number");

        }

        catch(Exception e)

        {

            System.out.println("invalid");

        }

    }

}

